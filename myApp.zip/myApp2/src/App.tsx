
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { useState } from 'react';
import Nav from './components/Nav';
import './App.css'
import House from './components/House';
import Multiples from './components/Multiples';
import Table from './components/Table';
import Form from './components/Form';
import Protec from './components/Protec'

function App() {
  const [isLogin,setLogin] = useState<boolean>(false);
  const logout = () => {
    setLogin(false);
  }
  const loggin = () => {
    setLogin(true)
  }

  return (
    <>
      <BrowserRouter>
      <Nav/>
      <Routes>
        <Route path='/' element={<House/>}/>
        <Route path='/mul/' element={<Protec isLogin={isLogin}><Multiples/></Protec>}>
          <Route path='/mul/table' element={<Table/>}/>
          <Route path='/mul/form' element={<Form/>}/>
        </Route>
      </Routes>
      {
        (isLogin)?(<button className='btn btn-dark' onClick={logout}>Logout</button>) : (<button className='btn btn-danger' onClick={loggin}>Login</button>)
      }
      </BrowserRouter>
    </>
  )
}

export default App
