import { Link, Outlet } from 'react-router-dom';

const Multiples = () => (
  <div>
    <h2>Multiples Page</h2>
    <nav>
      <Link to="Table">Table</Link>
      <Link to="Form" style={{ marginLeft: '10px' }}>Form</Link>
    </nav>
    <Outlet />
  </div>
);

export default Multiples;
