// // import { useNavigate } from "react-router-dom"


// const Home = () => {
//     // const navigate=useNavigate();
    
// // const gotonextpage=()=>{
// //     navigate('/succ');


// // }

//     return (
//         <>








//             {/* <div className="card">
//                 <div className="card-header">
//                     <h2>Login</h2>
//                 </div>
//                 <div className="card-body">
//                     <div className="form-group">
//                         <div className="row">
//                             <div className="col">
//                                 <label htmlFor="">Username | Phone</label>
//                                 <input type="text" name="" id="" className="form-control" />
//                             </div>
//                         </div>
//                     </div>
//                     <div className="form-group">
//                         <div className="row">
//                             <div className="col">
//                                 <label htmlFor="">Password</label>
//                                 <input type="password" name="" id="" className="form-control" />
//                             </div>
//                         </div>
//                     </div>
//                     <div className="form-group">
//                         <div className="row">
//                             <div className="col">
//                                 <input type="button" value="Login" onClick={gotonextpage} className="form-control btn btn-success" />

//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div> */}

        

//         </>
//     )
// }
// export default Home






import React from 'react';

const House: React.FC = () => {
  const images = [
    { src: 'goku2.jpg', alt: '1' },
    { src: 'naruto.jpg', alt: '2' },
    { src: 'ichigo.jpg', alt: '3' },
    { src: 'sukuna.jpg', alt: '4' },
    { src: 'luffy.jpg', alt: '5' },
    { src: 'ta.jpg', alt: '6' },
    { src: 'mob.jpg', alt: '7' },
    { src: 'kaneki.jpg', alt: '8' },
    { src: 'solo.jpg', alt: '9' },
    { src: 'ash.jpg', alt: '10'}
  ];

  const pageStyle: React.CSSProperties = {
    minHeight: '100vh',
    margin: '0',
    background: 'linear-gradient(to right, #6dd5ed, #2193b0)', // Gradient background
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  };

  const cardStyle: React.CSSProperties = {
    background: 'rgba(255, 255, 255, 0.95)',
    borderRadius: '12px',
    boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)',
    padding: '20px',
    margin: '20px auto',
    width: '95%', // Increased width
    maxWidth: '1800px', // Prevents it from being overly wide
    overflow: 'hidden',
  };

  const headingStyle: React.CSSProperties = {
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '2.5rem',
    color: '#333',
    textShadow: '1px 1px 4px rgba(0, 0, 0, 0.3)',
  };

  const containerStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', // Wider cells
    gap: '15px',
    padding: '10px',
    boxSizing: 'border-box',
  };

  const imageStyle: React.CSSProperties = {
    width: '100%',
    height: '150px', // Decreased height
    objectFit: 'cover',
    borderRadius: '10px',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.3)',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    cursor: 'pointer',
  };

  const imageHoverStyle: React.CSSProperties = {
    transform: 'scale(1.05)',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.5)',
  };

  const [hoveredIndex, setHoveredIndex] = React.useState<number | null>(null);

  return (
    <div style={pageStyle}>
      <div className="card" style={cardStyle}>
        <h1 style={headingStyle}>Welcome to the House Page</h1>
        <div style={containerStyle}>
          {images.map((image, index) => (
            <img
              key={index}
              src={image.src}
              alt={image.alt}
              style={hoveredIndex === index ? { ...imageStyle, ...imageHoverStyle } : imageStyle}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default House;
