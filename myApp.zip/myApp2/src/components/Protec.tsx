import { Navigate} from "react-router-dom";

interface abc{
    isLogin:any,
    children:any
}
const Protec:React.FC<abc>=({isLogin,children})=>{          //children props for about
   
   if(!isLogin){
    <Navigate to='/' replace/>
   }
   else{
    return children;
   }
 
    return(
        <>
        
        </>
    )
}
export default Protec;