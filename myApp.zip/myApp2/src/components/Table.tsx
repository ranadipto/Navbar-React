import { useState, useRef, useEffect, } from 'react';

interface Employee {
  empno: number;
  ename: string;
  doj: string;
  sal: number;
}

const Table = () => {
  const [employees, setEmployees] = useState<Employee[]>([
    { empno: 1, ename: 'John', doj: '12-12-2012', sal: 12000 },
    { empno: 2, ename: 'Smith', doj: '23-12-2002', sal: 11000 },
    { empno: 3, ename: 'Michael', doj: '21-08-2022', sal: 9000 },
    { empno: 4, ename: 'Diana', doj: '01-01-2023', sal: 22000 },
    { empno: 5, ename: 'Anjan', doj: '22-03-2020', sal: 14000 },
    { empno: 6, ename: 'Rohit', doj: '12-08-2021', sal: 4000 },
    { empno: 7, ename: 'Anju', doj: '14-11-2023', sal: 10000 },
    { empno: 8, ename: 'Tanmay', doj: '12-08-2021', sal: 24000 },
  ]);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>(employees);

  const sortRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (sortRef.current) {
      sortRef.current.focus();
    }
  }, []);

  useEffect(() => {
    setFilteredEmployees(employees);
  }, [employees]);

  const handleSort = (sortBy: 'ename' | 'doj' | 'sal', order: 'asc' | 'desc') => {
    const sortedEmployees = [...filteredEmployees].sort((a, b) => {
      if (sortBy === 'ename') {
        return order === 'asc' ? a.ename.localeCompare(b.ename) : b.ename.localeCompare(a.ename);
      } else if (sortBy === 'doj') {
        return order === 'asc'
          ? new Date(a.doj).getTime() - new Date(b.doj).getTime()
          : new Date(b.doj).getTime() - new Date(a.doj).getTime();
      } else {
        return order === 'asc' ? a.sal - b.sal : b.sal - a.sal;
      }
    });
    setFilteredEmployees(sortedEmployees);
  };

  const handleSearch = () => {
    const query = searchQuery.trim().toLowerCase();
    const results = employees.filter((employee) =>
      employee.ename.toLowerCase().includes(query)
    );
    setFilteredEmployees(results);
  };

  const handleDelete = (empno: number) => {
    const updatedEmployees = employees.filter((employee) => employee.empno !== empno);
    setEmployees(updatedEmployees);
  };

  const handleUpdate = (empno: number) => {
    const employeeToUpdate = employees.find((employee) => employee.empno === empno);
    if (employeeToUpdate) {
      const newName = window.prompt('Enter new name:', employeeToUpdate.ename);
      const newDoj = window.prompt('Enter new date of joining (YYYY-MM-DD):', employeeToUpdate.doj);
      const newSalary = window.prompt('Enter new salary:', employeeToUpdate.sal.toString());

      if (newName !== null && newDoj !== null && newSalary !== null) {
        const updatedEmployees = employees.map((employee) =>
          employee.empno === empno
            ? { ...employee, ename: newName, doj: newDoj, sal: parseInt(newSalary, 10) }
            : employee
        );
        setEmployees(updatedEmployees);
      }
    }
  };

  const handleAdd = () => {
    const newName = window.prompt('Enter employee name:');
    const newDoj = window.prompt('Enter date of joining (YYYY-MM-DD):');
    const newSalary = window.prompt('Enter salary:');

    if (newName !== null && newDoj !== null && newSalary !== null) {
      const newEmployee: Employee = {
        empno: employees.length > 0 ? employees[employees.length - 1].empno + 1 : 1,
        ename: newName,
        doj: newDoj,
        sal: parseInt(newSalary, 10),
      };
      setEmployees([...employees, newEmployee]);
    }
  };

  return (
    <div className="container mt-4">
      <h3>Employee List</h3>
  
      {/* Search Bar */}
      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Search by name"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button className="btn btn-info mt-2" onClick={handleSearch}>
          Search
        </button>
      </div>
  
      {/* Sort Buttons */}
      <div className="mb-3">
        <h5>Sort By:</h5>
        <button
          ref={sortRef}
          className="btn btn-secondary me-2"
          onClick={() => handleSort('ename', 'asc')}
        >
          Name (A-Z)
        </button>
        <button
          className="btn btn-secondary me-2"
          onClick={() => handleSort('ename', 'desc')}
        >
          Name (Z-A)
        </button>
        <button
          className="btn btn-secondary me-2"
          onClick={() => handleSort('doj', 'asc')}
        >
          Date of Joining (Oldest First)
        </button>
        <button
          className="btn btn-secondary me-2"
          onClick={() => handleSort('doj', 'desc')}
        >
          Date of Joining (Newest First)
        </button>
        <button
          className="btn btn-secondary me-2"
          onClick={() => handleSort('sal', 'asc')}
        >
          Salary (Low to High)
        </button>
        <button
          className="btn btn-secondary me-2"
          onClick={() => handleSort('sal', 'desc')}
        >
          Salary (High to Low)
        </button>
      </div>
  
      {/* Employee Table */}
      <table className="table table-bordered">
        <thead>
          <tr className="table-primary">
            <th>Employee Number</th>
            <th>Name</th>
            <th>Date of Joining</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map((employee) => (
            <tr key={employee.empno}>
              <td>{employee.empno}</td>
              <td>{employee.ename}</td>
              <td>{employee.doj}</td>
              <td>{employee.sal}</td>
              <td>
                <button
                  className="btn btn-danger me-2"
                  onClick={() => handleDelete(employee.empno)}
                >
                  Delete
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => handleUpdate(employee.empno)}
                >
                  Update
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
  
      {/* Add Employee Button */}
      <div className="mt-3">
        <button className="btn btn-success" onClick={handleAdd}>
          Add Employee
        </button>
      </div>
    </div>
  );
  
};

export default Table;
