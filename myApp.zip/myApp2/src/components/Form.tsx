import React, { useRef, useState } from 'react';

const Form = () => {
  const nRef = useRef<HTMLInputElement>(null);
  const nSuc = useRef<HTMLParagraphElement>(null);
  const nErr = useRef<HTMLParagraphElement>(null);
  const pRef = useRef<HTMLInputElement>(null);
  const cpRef = useRef<HTMLInputElement>(null);
  const cpSuc = useRef<HTMLParagraphElement>(null);
  const cpErr = useRef<HTMLParagraphElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);

  const [imageURL, setImageURL] = useState<string | null>(null);
  const [fdata, setFdata] = useState<any>(null);

  const nC = () => {
    if (nRef.current && nRef.current.value.length < 6) {
      nErr.current!.innerHTML = "Min 6 chars";
      nRef.current.classList.add("is-invalid");
      nSuc.current!.innerHTML = "";
      btnRef.current!.disabled = true;
    } else {
      nSuc.current!.innerHTML = "Valid name";
      nRef.current?.classList.add("is-valid");
      nRef.current?.classList.remove("is-invalid");
      nErr.current!.innerHTML = "";
      btnRef.current!.disabled = false;
    }
  };

  const cP = () => {
    if (cpRef.current && cpRef.current.value.length < 6) {
      cpErr.current!.innerHTML = "Min 6 chars";
      cpRef.current.classList.add("is-invalid");
      cpSuc.current!.innerHTML = "";
      btnRef.current!.disabled = true;
    } else {
      cpSuc.current!.innerHTML = "Passwords match";
      cpRef.current?.classList.add("is-valid");
      cpRef.current?.classList.remove("is-invalid");
      cpErr.current!.innerHTML = "";
      btnRef.current!.disabled = false;
    }
  };

  const upImg = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImageURL(url);
    }
  };

  const mySubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (nRef.current!.value.length < 6 || cpRef.current!.value.length < 6) {
      return;
    }
    const data = {
      name: nRef.current!.value,
      password: pRef.current!.value,
      confirmPassword: cpRef.current!.value,
      imageURL,
    };
    setFdata(data);
  };

  return (
    <>
      <div className="container mt-4">
        <form onSubmit={mySubmit}>
          <div className="form-group">
            <div className="row mb-3">
              <div className="col">
                <label htmlFor="name">Name</label>
                <input type="text" id="name" className="form-control" onKeyUp={nC} ref={nRef}/>
                <p ref={nSuc} className="text-success"></p>
                <p ref={nErr} className="text-danger"></p>
              </div>
            </div>
            <div className="row mb-3">
              <div className="col">
                <label htmlFor="password">Password</label>
                <input type="password" id="password" className="form-control" ref={pRef}/>
              </div>
              <div className="col">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input type="password" id="confirmPassword" className="form-control" onKeyUp={cP} ref={cpRef}/>
                <p ref={cpSuc} className="text-success"></p>
                <p ref={cpErr} className="text-danger"></p>
              </div>
            </div>
          </div>
          <div className="form-group mb-3">
            <label htmlFor="file">Upload Image</label>
            <input type="file" className="form-control" onChange={upImg} />
            {imageURL && (
              <div className="mt-3">
                <p>Image Preview:</p>
                <img src={imageURL} alt="Preview" width="150px" />
              </div>
            )}
          </div>
          <button type="submit" className="btn btn-warning" ref={btnRef} disabled={true}>Submit</button>
        </form>
      </div>

      <div className="card mt-4">
        <div className="card-header">
          <h3>Form Details:</h3>
        </div>
        <div className="card-body">
          {fdata && (
            <div>
              <p>Name: {fdata.name}</p>
              <p>Password: {fdata.password}</p>
              <p>Confirm Password: {fdata.confirmPassword}</p>
              {fdata.imageURL && (
                <div>
                  <p>Image Preview:</p>
                  <img src={fdata.imageURL} alt="Preview" width="150px" />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Form;
