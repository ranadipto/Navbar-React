
import { Link } from "react-router-dom";

const Nav = () => {
    const header:any={
        'display': 'flex',
        'justify-content': 'center'

    }
    const bodys:any={
        'padding': '25px',
        'list-style': 'none'
    }
    
  return (
    <>
    <ul style={header}>
            <li style={bodys}><Link to="/">Home</Link></li>
            <li style={bodys}><Link to="/mul">Multiples</Link></li>
        </ul>
    </>
  )
}

export default Nav;